package com.study.ch02;

public class StudentType extends Person { // extends 확장or상속 Person이라는 자료에서 확장 되었다는 뜻
    // Student 을 Person 에 상속 시킨다는 뜻
    // person은 상속되어있는 Student 로 변환이 가능하지만
    // 반대는 안됨
    int studentYear;
    String address; //이렇게 만들고 메인에 가서 실행시킨다

    }



