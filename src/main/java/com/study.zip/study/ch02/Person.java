package com.study.ch02;

public class Person {
    String name;
    int age;
}
