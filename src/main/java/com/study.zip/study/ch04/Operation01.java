package com.study.ch04;

public class Operation01 {
    public static void main(String[] args) {
        /*
           << 연산자 >>

           산술 연산자, 비교 연산자, 논리 연산자, 조건 연산자, 복합 대입 연산자
         */

        System.out.println("산술연산자");
        System.out.println("1 + 1 = " + (1 + 1));
        System.out.println("1 - 1 = " + (1 - 1));
        System.out.println("1 * 1 = " + (1 * 1));
        System.out.println("1 / 1 = " + (1 / 1)); // 나누기 - 몫
        System.out.println("10 % 3 = " + (10 % 3));// 나누기 - 나머지값




    }
}
