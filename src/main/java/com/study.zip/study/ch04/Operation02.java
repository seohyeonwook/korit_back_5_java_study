package com.study.ch04;

public class Operation02 {
    public static void main(String[] args) {
        /*
           << 연산자 >>

           산술 연산자, 비교 연산자, 논리 연산자, 조건 연산자, 복합 대입 연산자
         */

        System.out.println(true);
        System.out.println(false);

        boolean flag = true;

        System.out.println("비교연산자"); // true 또는 ralse 값으로만 나온다
        System.out.println(" > " + (10 > 2));
        System.out.println(" > " + flag);
        System.out.println(" < " + (10 < 2));
        System.out.println(" >= " + (10 >= 10)); // 이상 이하는 잘 안쓴다
        System.out.println(" <= " + (10 <= 2));
        System.out.println(" == " + (10 == 2)); // 같다
        System.out.println(" != " + (10 != 2)); // 다르다




    }
}
