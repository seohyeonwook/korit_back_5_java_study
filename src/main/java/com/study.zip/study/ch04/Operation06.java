package com.study.ch04;

public class Operation06 {
    public static void main(String[] args) {
        /*
           << 문제 >>

           조건연산다(삼항연산자)

           a > 0 ? "양수" : a == 0 ? "0" : "음수" //?: 사이에 있는 값이 참 뒤에가 거짓


         */
//        int iResult = 10 > 2 ? 1111 : 2222;// 결과값들의 자료형이 일치하여야 한다  int 면 숫자
//        String sResult = 10 > 2 ? "1111" : "2222";
//        boolean bResult = 10 > 2 ? true : false; // 단순하게 생각하자 코딩은 단순하게
//        boolean bResult2 = 10 > 2; // 이렇게만 해도됨
//
//        String name = unll;
//        System.out.println(name == unll);





    }
}
